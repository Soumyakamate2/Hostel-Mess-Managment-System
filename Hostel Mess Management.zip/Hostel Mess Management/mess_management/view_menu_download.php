<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <title>VKIT Hostel Mess</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <link href="own.css" rel="stylesheet" type="text/css">
        <style>
        table, th, td {
          border: 1px solid black;
          border-collapse: collapse;
        }
        th, td {
          padding: 5px;
          text-align: left;
        }
        </style>
    </head>
    <body>
        <?php
        include 'after_login_header.php';
        include 'dbh.php';
        $sql1="SELECT * FROM menu";
        $result1=mysqli_query($conn, $sql1); 
        ?>
        <br><br><br><br> <br>
        <div class="around_form" style="margin-bottom: 5%">
            <div class="left_own">
                <h2>MENU</h2>
                <a style="margin-left:38%; " href="download_menu.php" class="btn btn-primary">Download</a> 
                <br><br>
                <div class="row_1">
                    <table style="width:100%">
                        <tr>
                            <th>
                                DAY
                            </th>
                            <th>
                                BREAKFAST
                            </th>
                            <th>
                                LUNCH   
                            </th>
                            <th>
                                SNACKS
                            </th>
                           <th>
                                DINNER
                            </th>                            
                        </tr>
                        <?php
                                while ($row1 = mysqli_fetch_array($result1)) { 
                                    
                        ?>
                            <tr>
                                <td>
                                    <?php
                                    echo $row1["day"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row1["bf"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row1["lunch"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row1["snacks"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row1["dinner"];
                                    ?>
                                </td>
                                
                            </tr>
                        <?php            
                                }
                        ?>
                        
                        
                    </table>
                </div>
            </div>
        </div>
        
        <br><br><br><br> <br><br><br><br><br><br><br><br>
        <?php
        include 'footer.php';
        ?>
    </body>
</html>
