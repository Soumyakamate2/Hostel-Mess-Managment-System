<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include 'dbh.php';
session_start();
date_default_timezone_set('asia/calcutta');
$str="";
if (isset($_POST['bf'])) {
$bf = 1;
$str=$str."Breakfast booked,";
} else {
$bf = 0;
$str=$str."Breakfast not booked,";
}
if (isset($_POST['lunch'])) {
$lunch = 1;
$str=$str."lunch booked,";
} else {
$lunch = 0;
$str=$str."lunch not booked,";
}
if (isset($_POST['snacks'])) {
$snacks = 1;
$str=$str."snacks booked,";
} else {
$snacks = 0;
$str=$str."snacks not booked,";
}
if (isset($_POST['dinner'])) {
$dinner = 1;
$str=$str."dinner booked,";
} else {
$dinner = 0;
$str=$str."dinner not booked,";
}
$usn=$_SESSION['name'];
$date=$_SESSION['date'];

$sql = "SELECT * FROM booking WHERE usn ='$usn' AND date ='$date'";
$check = mysqli_fetch_array(mysqli_query($conn,$sql));
if(isset($check)){
echo 'already Booked';
print "<script type='text/javascript'>alert('already Booked');window.location='book_meal.php';</script>";
}else{
$sql1 = "INSERT INTO booking (usn,date,bf,lunch,snacks,dinner) VALUES('$usn','$date',$bf,$lunch,$snacks,$dinner)";
if(mysqli_query($conn,$sql1)){
        echo 'successfully booked'.$date;
        print "<script type='text/javascript'>alert('$str');window.location='book_meal.php';</script>";
}
}
?>