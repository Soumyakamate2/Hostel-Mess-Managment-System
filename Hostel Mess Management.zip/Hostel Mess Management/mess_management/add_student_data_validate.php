<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <title>VKIT Hostel Mess</title>
       
    </head>
    <body>
        <?php
       include 'dbh.php';
       
            $uname = $_POST["full-name"];
            $pass = $_POST["pass"];
            $usn=$_POST["usn"];
            $email=$_POST["email-address"];
            $phone=$_POST["phoneno"];
            $room_no=$_POST["room_no"];
            $year=$_POST["year"];            
            
            
            $sql = "UPDATE users SET pass = '$pass',email = '$email',phone = '$phone',room_no = '$room_no',YEAR = '$year' WHERE usn = '$usn' AND NAME = '$uname' ;";
              $inserted = mysqli_query($conn, $sql);
             if($inserted == 1)
            {              
                 echo 'successfull';
                 print "<script type='text/javascript'>alert('Successfully Add Details');window.location='logout.php';</script>";
            }
            else
            {
                
                echo 'unsuccessfull';
            }
           
         
        ?>
    </body>
</html>
