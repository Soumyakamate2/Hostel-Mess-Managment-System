<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
            
         <title>VKIT Hostel Mess</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">



    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script type="text/javascript">
   function check_pwd(){
    var pwd=document.getElementById("password").value;
     var cpwd=document.getElementById("confirm_password").value;
     
     if(pwd!=cpwd){
         alert("password and confirm passward not match");
         return false;
     }
 }     
    

    </script>
    </head>
    <body>
        <?php
    include 'index.html';
    ?>
       <br><br><br><br> <br>
        <?php
        if(isset($_POST["submit"])){
                                include 'dbh.php';
                                $phone_comfirm=0;
                                $usn1=$_POST['usn'];
                                $phone=$_POST['phoneno'];
                                $sql="select * from users where usn='$usn1'";
                                $result=mysqli_query($conn, $sql);
                                $count= mysqli_num_rows($result);
                                
                                if($count>0){
                                while ($row1 = mysqli_fetch_array($result)) {
                                    $phone_comfirm=$row1["phone"];
                                }
                                if($phone!=$phone_comfirm){
                                   print "<script type='text/javascript'>alert('Phone Number Invalid');window.location='forgot_password.php';</script>";    
                                }else{
                                    ?>
        <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Forgot Password</div>
                        <div class="card-body">
                            <form onsubmit="return check_pwd()" action="change_pass_php.php?usn=<?php echo $usn1; ?>" method="post">
                         <div class="form-group row">
                                    <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                                    <div class="col-md-6">
                                        <input type="password" required id="password" class="form-control" name="pass">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="confirm_password" class="col-md-4 col-form-label text-md-right">Confirm Password</label>
                                    <div class="col-md-6">
                                        <input type="password" required id="confirm_password" class="form-control" name="c_pass">
                                    </div>
                                </div>
                        <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary" name="change_password" >
                                        Change Password
                                        </button>
                                    </div>
                            </form>
                        </div></div></div></div></div>
                            <?php
                                }
                                }else{
                                     print "<script type='text/javascript'>alert('USN Invalid $usn1');window.location='forgot_password.php';</script>";  
                                }
                            } 
       
        ?>
       <br>
        <?php
include 'footer.php';
?>
    </body>
</html>
