<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <title>VKIT Hostel Mess</title>
       
    </head>
    <body>
        <?php
       include 'dbh.php';
       
            $uname = $_POST["full-name"];            
            $usn=$_POST["usn"];
            $pass = $usn;                       
            $utype="student";
            $status="yes";
            
            $sql = "INSERT INTO users(usn,name,pass,utype,status)VALUES('$usn','$uname','$pass','$utype','$status');";
                        
              $inserted = mysqli_query($conn, $sql);
             if($inserted == 1)
            {
               //header("Location:registered_successfull.php");
              
                 echo 'successfull';
                 print "<script type='text/javascript'>alert('Successfully Added Student');window.location='add_student.php';</script>";
            }
            else
            {
               
                echo 'unsuccessfull';
            }
           
         
        ?>
    </body>
</html>
