<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <title>VKIT Hostel Mess</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <link href="own.css" rel="stylesheet" type="text/css">
        <style>
        table, th, td {
          border: 1px solid black;
          border-collapse: collapse;
        }
        th, td {
          padding: 5px;
          text-align: left;
        }
        </style>
    </head>
    <body>
        <?php
        include 'after_login_header.php';
        include 'dbh.php';
        $sql1="SELECT usn,NAME,room_no,YEAR,phone,email FROM users where STATUS='yes' and utype='student';";
        $result1=mysqli_query($conn, $sql1); 
        ?>
        <br><br><br><br> <br>
          
        <div class="around_form" style="margin-bottom: 10%">
            
            
                        
            <div class="left_own">
                <h2>Students
                </h2>
                <a style="margin-left:38%; " href="download.php" class="btn btn-primary">Download</a> 
                <br><br>
                <div class="row_1" style="overflow-x:auto;margin-bottom: 20%;">
                    <table style="width:100%" >
                        <tr>
                            <th>
                                USN
                            </th>
                            <th>
                                Name
                            </th>
                            <th>
                                Room No.
                            </th>
                            <th>
                                Year
                            </th>
                           <th>
                                Phone No.
                            </th>
                            <th>
                                Email ID
                            </th>
                            <th>
                                Delete
                            </th>
                        </tr>
                        <?php
                                while ($row1 = mysqli_fetch_array($result1)) { 
                                    $usn=$row1["usn"];
                        ?>
                            <tr>
                                <td>
                                    <?php
                                    echo $row1["usn"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row1["NAME"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row1["room_no"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row1["YEAR"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row1["phone"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo $row1["email"];
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    echo "<a href='delete_student.php?usn=$usn'>"
                                    ."Delete</a>";
                                    ?>
                                </td>
                            </tr>
                        <?php            
                                }
                        ?>
                        
                        
                    </table>
                    
                </div>
                
            </div>
        </div>
        
        <?php
        
        
        
        ?>
        <br><br><br><br> <br><br><br><br><br>
        <?php
        include 'footer.php';
        ?>
    </body>
</html>
