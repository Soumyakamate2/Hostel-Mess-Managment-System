<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>VKIT Hostel Mess</title>
        
        <style>
           


            </style>
    </head>
    <body>
        <?php
        // put your code here
        ?>
        <!-- Footer -->
  <footer class="footer text-center sticky-bottom" >
    <div class="container">
      <div class="row">

        <!-- Footer Location -->
        <div class="col-lg-4 mb-5 mb-lg-0">
          <h4 class="text-uppercase mb-4">Location</h4>
          <p class="lead mb-0">Gudimavu, Kumbalagodu Post 
          <br>Kumbalagodu Hobli<br>Bengaluru 560074</p>
        </div>

        <!-- Footer Social Icons -->
        <div class="col-lg-4 mb-5 mb-lg-0">
          <h4 class="text-uppercase mb-4">Around the Web</h4>
          <a class="btn btn-outline-light btn-social mx-1" href="https://www.facebook.com/Vivekananda-Institute-of-Technology-VKIT-Alumni-Bangalore-101741223682216/">
            <i class="fab fa-fw fa-facebook-f"></i>
          </a>
          <a class="btn btn-outline-light btn-social mx-1" href="https://twitter.com/vkitbangalore?lang=en">
            <i class="fab fa-fw fa-twitter"></i>
          </a>
          <a class="btn btn-outline-light btn-social mx-1" href="#">
            <i class="fab fa-fw fa-linkedin-in"></i>
          </a>
          
        </div>

        <!-- Footer About Text -->
        <div class="col-lg-4">
          <h4 class="text-uppercase mb-4">About Hostel Mess</h4>
          <p class="lead mb-0">Well-appointed rooms for single/double occupancy with attached/common baths</p>
        </div>

      </div>
        
    </div>
     
  </footer>

  <!-- Copyright Section -->
   <section class="copyright py-4 text-center text-white footer_copy">
    <div class="container">
      <small>Copyright &copy; Rajath Praveen Raj & Prerit S Sobhani 2019</small>
    </div>
  </section>

  <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
  <div class="scroll-to-top d-lg-none position-fixed ">
    <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
      <i class="fa fa-chevron-up"></i>
    </a>
  </div>

 
    </body>
</html>
