<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
       
         <title>VKIT Hostel Mess</title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">



    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="own.css">
   
    </head>
    <body>
        <?php
        include 'after_login_header.php';
        date_default_timezone_set('asia/calcutta');
        $time=date("H:i");
        $bf=0;
        $lunch=0;
        $snacks=0;
        $dinner=0;
        $_SESSION['date']=date("Y-m-d");
        ?>
        <br><br><br><br> <br>
        <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Booking Meal for Date: <?php echo date("d-m-Y");?></div>
                        <div class="card-body">
                            <h4>Select the meals</h4>
                            <form   action="book_meal_phpcode.php" method="post">
                                <div class="form-group row">
                                    <label for="name" class="left_own_check">
                                    <?php
                                    $bfTime_start ="08:00";
                                    $bfTime_end="23:59";
                                    if(($time>$bfTime_start)&&($time<$bfTime_end)){
                                    ?>
                                        <input type="checkbox" disabled name="bf" value="0">Breakfast
                                    <?php
                                    } else { ?>
                                    <input type="checkbox" name="bf" value="1">Breakfast
                                    <?php    
                                    }
                                    ?>
                                        </label>
                                </div>
                                <br>
                                
                                <div class="form-group row">
                                    <label for="name" class="left_own_check">
                                    <?php
                                    $lunchTime_start ="12:00";
                                    $lunchTime_end="23:59";
                                    if(($time>$lunchTime_start)&&($time<$lunchTime_end)){
                                    ?>
                                    <input type="checkbox" disabled name="lunch" value="0">Lunch
                                    <?php
                                    } else { ?>
                                    <input type="checkbox" name="lunch" value="1">Lunch
                                    <?php    
                                    }
                                    ?>
                                        </label>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <label for="name" class="left_own_check">
                                    <?php
                                    $snacksTime_start ="16:00";
                                    $snacksTime_end="23:59";
                                    if(($time>$snacksTime_start)&&($time<$snacksTime_end)){
                                    ?>
                                    <input type="checkbox" disabled name="snacks" value="0">Snacks
                                    <?php
                                    } else { ?>
                                    <input type="checkbox" name="snacks" value="1">Snacks
                                    <?php    
                                    }
                                    ?>
                                        </label>
                                </div>
                                <br>
                                <div class="form-group row">
                                    <label for="name" class="left_own_check">
                                    <?php
                                    $dinnerTime_start ="21:00";
                                    $dinnerTime_end="23:59";
                                    if(($time>$dinnerTime_start)&&($time<$dinnerTime_end)){
                                    ?>
                                    <input type="checkbox" disabled name="dinner" value="0">Dinner
                                    <?php
                                    } else { ?>
                                    <input type="checkbox" name="dinner" value="1">Dinner
                                    <?php    
                                    }
                                    ?>
                                        </label>
                                </div>
                                <br>
                               <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary">
                                        Book
                                        </button>
                                    </div>
                               
                            </form>
                             </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    <br>
<?php
        include 'footer.php';
        ?>
    </body>
</html>
