<?php
  include 'dbh.php';
  include 'fpdf.php';
   $sql1="SELECT * FROM menu";
   $result1=mysqli_query($conn, $sql1); 
    if($result1->num_rows > 0){
    $delimiter = ",";
    $filename = "menu_" . date('Y-m-d') . ".csv";
    
    //create a file pointer
    $f = fopen('php://memory', 'w');
    
    //set column headers
    $fields = array('DAY', 'BREAKFAST', 'LUNCH', 'SNACKS','DINNER');
    fputcsv($f, $fields, $delimiter);
    
    //output each row of the data, format line as csv and write to file pointer
    while($row = $result1->fetch_assoc()){
        $lineData = array($row['day'], $row['bf'], $row['lunch'], $row['snacks'], $row['dinner']);
        fputcsv($f, $lineData, $delimiter);
    }
    
    //move back to beginning of file
    fseek($f, 0);
    
    //set headers to download file rather than displayed
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '";');
    
    //output all remaining data on a file pointer
    fpassthru($f);
    
}
exit;

       
?>
